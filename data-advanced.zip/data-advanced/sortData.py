# importing packages
import os
import pandas as pd

# setting path
os.chdir('C:/Users/User/Documents/Thesis/Modeling/data-advanced')

# reading csv
branch = pd.read_csv('df_branch_final.csv',usecols=['BranchID','FromBus','ToBus','Pmax'])
bus = pd.read_csv('df_bus_final.csv', usecols=['BusID','Zone'])
plant = pd.read_csv('df_gen_final.csv',sep=';', usecols=['GenID','OnBus','Pmax','Type','Costs','Zone'])
load = pd.read_csv('df_bus_load_added_abroad_final.csv')
incidence = pd.read_csv('matrix_A_final.csv')
susceptance = pd.read_csv('matrix_Bd_final.csv')

# give information about csv
# branch.info()
# bus.info()
# plant.info()
# load.info()
# incidence.info()
# susceptance.info()

# identifying abroad
abroad = ['Import/Export_1', 'Import/Export_2', 'Import/Export_3']
bus_abroad = bus.loc[bus['Zone'].isin(abroad)]
idx_bus_abroad = bus_abroad[:].index
bus_abroad = bus_abroad['BusID'].tolist()
# plant_abroad = plant.loc[plant['Zone'].isin(abroad)]
# plant_abroad = plant_abroad['GenID'].tolist()
branch_abroad = branch.loc[(branch['FromBus'].isin(bus_abroad))|(branch['ToBus'].isin(bus_abroad))]
idx_branch_abroad = branch_abroad[:].index
branch_abroad = branch_abroad['BranchID'].tolist()

# deleting abroad
bus = bus.loc[~bus['Zone'].isin(abroad)]
plant = plant.loc[~plant['Zone'].isin(abroad)]
branch = branch.loc[~(branch['FromBus'].isin(bus_abroad)|branch['ToBus'].isin(bus_abroad))]
load = load.drop(load.columns[idx_bus_abroad], axis=1)
incidence = incidence.drop(incidence.columns[idx_bus_abroad], axis=1)
incidence = incidence.drop(idx_branch_abroad)
susceptance = susceptance.drop(susceptance.columns[idx_branch_abroad],axis=1)
susceptance = susceptance.drop(idx_branch_abroad)

# write zones as int
bus = bus.astype({'Zone': int})
plant = plant.astype({'Zone': int})

# investing renewables
total_demand = round(load.sum(axis=1).iloc[0])
print("Total demand equals ", total_demand, " MW")

no_cost_plants = plant.loc[plant['Costs'] == 0]
total_no_cost_supply = round(no_cost_plants['Pmax'].sum())
print("Total zero cost supply equals ", total_no_cost_supply, " MW")

# reducing Pmax with load factor
load_factor = {
    "Wind": 0.3,
    "Wind Offshore":0.4,
    "PV": 0.2,
    "Nuclear": 0.9,#0.9
    "Gas/CCGT": 0.6,#0.6
    "Hard Coal": 0.5,#0.5
    "Lignite": 0.1 #0.1
}

for index_label, row_series in plant.iterrows():
    lf = load_factor.get(row_series["Type"])
    plant.at[index_label, "Pmax"] = row_series["Pmax"] * lf

no_cost_plants = plant.loc[plant['Costs'] == 0]
total_no_cost_supply = round(no_cost_plants['Pmax'].sum())
print("Total zero cost supply equals ", total_no_cost_supply, " MW")

# give information about csv
# branch.info()
# bus.info()
# plant.info()
# load.info()
# incidence.info()
# susceptance.info()

# writing csv
branch.to_csv("branch.csv", index=False)
bus.to_csv("bus.csv", index=False)
plant.to_csv("plant.csv", index=False)
load.to_csv("load.csv", index=False)
incidence.to_csv("incidence.csv", index=False)
susceptance.to_csv("susceptance.csv", index=False)