import os
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

# setting path
os.chdir('C:/Users/User/Documents/Thesis/Modeling/data-basic')

# reading csv
branch = pd.read_csv('branch.csv')
bus = pd.read_csv('bus.csv')
plant = pd.read_csv('plant.csv')
load = pd.read_csv('load.csv')
incidence = pd.read_csv('incidence.csv')
susceptance = pd.read_csv('susceptance.csv')
GEN = pd.read_csv('GEN.csv')
NP = pd.read_csv('NP.csv')
CG = pd.read_csv('CG.csv')
Fp = pd.read_csv('Fp.csv')
UP = pd.read_csv('UP.csv')
DOWN = pd.read_csv('DOWN.csv')
CC = pd.read_csv('CC.csv')

# Figure 1 : Flows in transmission lines
fig, ax = plt.subplots()

L = branch.BranchID.tolist()
Fp = list(abs(value) for value in Fp.loc[0])
Fmax = list(branch.Pmax)

ax.bar(L, Fp)
ax.plot(L, Fmax, 'r_', markersize=20, markeredgewidth=5)

ax.set_title('Flows in transmission lines')
ax.set_xticks(L)
ax.set_ylabel('MW')

# Figure 2 : Generation of power plants
fig, ax = plt.subplots()

P = plant.GenID.tolist()
GEN = list(GEN.loc[0])
Pmax = branch.Pmax.tolist()
UP = list(UP.loc[0])
DOWN = list(DOWN.loc[0])
GENDOWN = list(gen-down for gen, down in zip(GEN, DOWN))

ax.bar(P, GENDOWN)
ax.bar(P, DOWN, color="red", bottom=GENDOWN)
ax.bar(P, UP, color="green", bottom=GENDOWN)

ax.set_title('Generation of power plants')
ax.set_xticks(P)
ax.set_ylabel('MW')

plt.show()