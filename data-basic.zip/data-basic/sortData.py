# importing packages
import os
import pandas as pd

# setting path
os.chdir('C:/Users/User/Documents/Thesis/Modeling/data-basic')

# reading csv
branch = pd.read_csv('branch.csv', usecols=['BranchID','FromBus','ToBus','Pmax'])
bus = pd.read_csv('bus.csv', usecols=['BusID','Zone'])
plant = pd.read_csv('plant.csv', usecols=['GenID','OnBus','Pmax','Costs','Zone'])
load = pd.read_csv('load.csv')
incidence = pd.read_csv('incidence.csv')
susceptance = pd.read_csv('susceptance.csv')

# write int as floats
# branch = branch.astype({'Pmax':float})
# plant = plant.astype({'Pmax':float, 'Costs':float})
# load = load.astype(float)
# susceptance = susceptance.astype(float)

# give information about csv
# branch.info()
# bus.info()
# plant.info()
# load.info()
# incidence.info()
# susceptance.info()

# writing csv
branch.to_csv("branch.csv", index=False)
bus.to_csv("bus.csv", index=False)
plant.to_csv("plant.csv", index=False)
load.to_csv("load.csv", index=False)
incidence.to_csv("incidence.csv", index=False)
susceptance.to_csv("susceptance.csv", index=False)